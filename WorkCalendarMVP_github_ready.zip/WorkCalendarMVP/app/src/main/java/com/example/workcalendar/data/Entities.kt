package com.example.workcalendar.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "tasks",
    primaryKeys = ["num"]
)
data class TaskEntity(
    val num: Int,
    val row: Int,
    val block: String,
    val process: String,
    val description: String,
    val timeOfDay: String
)

@Entity(
    tableName = "allocations",
    foreignKeys = [
        ForeignKey(
            entity = TaskEntity::class,
            parentColumns = ["num"],
            childColumns = ["taskNum"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("taskNum"), Index("date")]
)
data class AllocationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val taskNum: Int,
    val date: String,     // YYYY-MM-DD
    val minutes: Int
)

@Entity(
    tableName = "comments",
    primaryKeys = ["taskNum", "date"],
    indices = [Index("date")]
)
data class CommentEntity(
    val taskNum: Int,
    val date: String,     // YYYY-MM-DD
    val text: String,
    val updatedAtEpochMs: Long
)
