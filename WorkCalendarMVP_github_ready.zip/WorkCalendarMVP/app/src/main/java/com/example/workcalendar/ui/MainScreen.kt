package com.example.workcalendar.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.workcalendar.WorkCalendarViewModel
import java.time.Instant
import java.time.ZoneId

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: WorkCalendarViewModel) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current

    var showPicker by remember { mutableStateOf(false) }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) vm.importComments(context, uri)
    }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.toast) {
        val msg = state.toast
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(message = msg)
            vm.clearToast()
        }
    }

    LaunchedEffect(state.shareUriString) {
        val s = state.shareUriString
        if (!s.isNullOrBlank()) {
            val uri = Uri.parse(s)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Отправить файл"))
            vm.clearShareUri()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Календарь работ") },
                actions = {
                    TextButton(onClick = { showPicker = true }) { Text(state.selectedDate.toString()) }
                    TextButton(onClick = { vm.exportComments(context) }) { Text("Экспорт") }
                    TextButton(onClick = { vm.exportAndShare(context) }) { Text("Поделиться") }
                    TextButton(onClick = { importLauncher.launch(arrayOf("application/json")) }) { Text("Импорт") }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(12.dp)
        ) {
            if (state.isLoading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
            }

            if (state.rows.isEmpty()) {
                Text("На эту дату задач нет.")
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(state.rows, key = { it.taskNum }) { row ->
                        TaskCard(
                            taskNum = row.taskNum,
                            title = row.process,
                            subtitle = row.block,
                            description = row.description,
                            timeOfDay = row.timeOfDay,
                            minutes = row.minutes,
                            initialComment = row.comment.orEmpty(),
                            onSave = { text -> vm.saveComment(row.taskNum, state.selectedDate, text) }
                        )
                    }
                }
            }
        }
    }

    if (showPicker) {
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = state.selectedDate
                .atStartOfDay(ZoneId.systemDefault())
                .toInstant()
                .toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    val ms = pickerState.selectedDateMillis
                    if (ms != null) {
                        val date = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()
                        vm.setDate(date)
                    }
                    showPicker = false
                }) { Text("Ок") }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("Отмена") } }
        ) {
            DatePicker(state = pickerState)
        }
    }
}

@Composable
private fun TaskCard(
    taskNum: Int,
    title: String,
    subtitle: String,
    description: String,
    timeOfDay: String,
    minutes: Int,
    initialComment: String,
    onSave: (String) -> Unit
) {
    var comment by remember(taskNum, initialComment) { mutableStateOf(initialComment) }

    Card {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Text(description, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AssistChip(onClick = {}, label = { Text("$minutes мин") })
                AssistChip(onClick = {}, label = { Text(timeOfDay) })
            }

            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = comment,
                onValueChange = { comment = it },
                label = { Text("Комментарий на дату") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { onSave(comment) }) { Text("Сохранить") }
        }
    }
}
