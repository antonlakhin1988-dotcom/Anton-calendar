package com.example.workcalendar

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.workcalendar.data.AppDatabase
import com.example.workcalendar.data.CommentEntity
import com.example.workcalendar.data.CommentsIo
import com.example.workcalendar.data.TaskForDateRow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate

data class UiState(
    val selectedDate: LocalDate = LocalDate.now(),
    val rows: List<TaskForDateRow> = emptyList(),
    val isLoading: Boolean = false,
    val toast: String? = null,
    val shareUriString: String? = null
)

class WorkCalendarViewModel(
    private val db: AppDatabase
) : ViewModel() {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    init {
        refresh()
    }

    fun setDate(date: LocalDate) {
        _state.value = _state.value.copy(selectedDate = date)
        refresh()
    }

    fun refresh() {
        val dateStr = _state.value.selectedDate.toString()
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true)
            val rows = db.dao().tasksForDate(dateStr)
            _state.value = _state.value.copy(rows = rows, isLoading = false)
        }
    }

    fun saveComment(taskNum: Int, date: LocalDate, text: String) {
        val trimmed = text.trim()
        viewModelScope.launch {
            db.dao().upsertComment(
                CommentEntity(
                    taskNum = taskNum,
                    date = date.toString(),
                    text = trimmed,
                    updatedAtEpochMs = System.currentTimeMillis()
                )
            )
            refresh()
            _state.value = _state.value.copy(toast = "Сохранено")
        }
    }

    fun clearToast() {
        _state.value = _state.value.copy(toast = null)
    }

    fun clearShareUri() {
        _state.value = _state.value.copy(shareUriString = null)
    }

    fun exportComments(context: Context) {
        viewModelScope.launch {
            val comments = db.dao().getAllComments()
            val uri = CommentsIo.exportToDownloads(context, comments)
            _state.value = _state.value.copy(
                toast = if (uri != null) "Экспортировано в Загрузки" else "Не удалось экспортировать"
            )
        }
    }

    fun exportAndShare(context: Context) {
        viewModelScope.launch {
            val comments = db.dao().getAllComments()
            val uri: Uri? = CommentsIo.exportToDownloads(context, comments)
            _state.value = _state.value.copy(
                toast = if (uri != null) "Готово к отправке" else "Не удалось экспортировать",
                shareUriString = uri?.toString()
            )
        }
    }

    fun importComments(context: Context, uri: Uri) {
        viewModelScope.launch {
            try {
                val dtos = CommentsIo.readFromUri(context, uri)
                val entities = dtos.map {
                    CommentEntity(
                        taskNum = it.taskNum,
                        date = it.date,
                        text = it.text,
                        updatedAtEpochMs = it.updatedAtEpochMs
                    )
                }
                db.dao().upsertComments(entities)
                refresh()
                _state.value = _state.value.copy(toast = "Импортировано: ${entities.size}")
            } catch (e: Exception) {
                _state.value = _state.value.copy(toast = "Ошибка импорта")
            }
        }
    }

    companion object {
        fun factory(db: AppDatabase): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    @Suppress("UNCHECKED_CAST")
                    return WorkCalendarViewModel(db) as T
                }
            }
    }
}
