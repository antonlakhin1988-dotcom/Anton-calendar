package com.example.workcalendar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.workcalendar.ui.MainScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as WorkCalendarApp

        setContent {
            val vm: WorkCalendarViewModel = viewModel(factory = WorkCalendarViewModel.factory(app.db))
            MainScreen(vm = vm)
        }
    }
}
