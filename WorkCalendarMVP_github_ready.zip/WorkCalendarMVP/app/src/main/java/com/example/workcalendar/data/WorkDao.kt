package com.example.workcalendar.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

data class TaskForDateRow(
    val taskNum: Int,
    val block: String,
    val process: String,
    val description: String,
    val timeOfDay: String,
    val minutes: Int,
    val comment: String?
)

@Dao
interface WorkDao {

    @Query(
        "SELECT " +
                "t.num as taskNum, " +
                "t.block as block, " +
                "t.process as process, " +
                "t.description as description, " +
                "t.timeOfDay as timeOfDay, " +
                "a.minutes as minutes, " +
                "c.text as comment " +
        "FROM allocations a " +
        "JOIN tasks t ON t.num = a.taskNum " +
        "LEFT JOIN comments c ON c.taskNum = a.taskNum AND c.date = a.date " +
        "WHERE a.date = :date " +
        "ORDER BY t.block, t.num"
    )
    suspend fun tasksForDate(date: String): List<TaskForDateRow>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTasks(tasks: List<TaskEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAllocations(items: List<AllocationEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertComment(comment: CommentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertComments(comments: List<CommentEntity>)

    @Query("SELECT * FROM comments ORDER BY updatedAtEpochMs DESC")
    suspend fun getAllComments(): List<CommentEntity>

    @Query("SELECT COUNT(*) FROM tasks")
    suspend fun taskCount(): Int
}
