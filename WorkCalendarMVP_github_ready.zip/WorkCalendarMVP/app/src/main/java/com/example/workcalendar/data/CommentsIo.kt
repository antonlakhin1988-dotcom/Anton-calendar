package com.example.workcalendar.data

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.BufferedReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CommentsIo {

    @Serializable
    data class CommentDto(
        val taskNum: Int,
        val date: String,
        val text: String,
        val updatedAtEpochMs: Long
    )

    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
    private val listSer = ListSerializer(CommentDto.serializer())

    fun exportToDownloads(context: Context, comments: List<CommentEntity>): Uri? {
        val dt = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        val fileName = "workcalendar_comments_$dt.json"

        val bytes = json.encodeToString(
            listSer,
            comments.map { CommentDto(it.taskNum, it.date, it.text, it.updatedAtEpochMs) }
        ).toByteArray(Charsets.UTF_8)

        val resolver = context.contentResolver

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/")
            }
        }

        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val uri = resolver.insert(collection, values) ?: return null

        resolver.openOutputStream(uri)?.use { out ->
            out.write(bytes)
            out.flush()
        } ?: return null

        return uri
    }

    fun readFromUri(context: Context, uri: Uri): List<CommentDto> {
        val resolver: ContentResolver = context.contentResolver
        val text = resolver.openInputStream(uri)?.use { input ->
            BufferedReader(input.reader(Charsets.UTF_8)).readText()
        } ?: return emptyList()

        return json.decodeFromString(listSer, text)
    }
}
