package com.example.workcalendar.data

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.BufferedReader

object SeedImporter {

    @Serializable
    data class GanttFile(
        val month: String,
        val city: String,
        val tasks: List<GanttTask>,
        val dates: List<String>
    )

    @Serializable
    data class GanttTask(
        val row: Int,
        val num: Int,
        val block: String,
        val process: String,
        val description: String,
        val timeOfDay: String,
        val allocations: Map<String, Double>,
        val totalMinutes: Double
    )

    private val json = Json { ignoreUnknownKeys = true }

    suspend fun importFromAssetsIfEmpty(context: Context, db: AppDatabase) {
        val dao = db.dao()
        if (dao.taskCount() > 0) return

        val text = context.assets.open("gantt_march_2026.json").use { input ->
            BufferedReader(input.reader(Charsets.UTF_8)).readText()
        }
        val file = json.decodeFromString(GanttFile.serializer(), text)

        val tasks = file.tasks.map {
            TaskEntity(
                num = it.num,
                row = it.row,
                block = it.block,
                process = it.process,
                description = it.description,
                timeOfDay = it.timeOfDay
            )
        }
        dao.upsertTasks(tasks)

        val allocations = file.tasks.flatMap { t ->
            t.allocations.entries.map { (date, mins) ->
                AllocationEntity(
                    taskNum = t.num,
                    date = date,
                    minutes = mins.toInt()
                )
            }
        }
        dao.upsertAllocations(allocations)
    }
}
