package com.example.workcalendar

import android.app.Application
import com.example.workcalendar.data.AppDatabase

class WorkCalendarApp : Application() {
    lateinit var db: AppDatabase
        private set

    override fun onCreate() {
        super.onCreate()
        db = AppDatabase.build(this)
    }
}
